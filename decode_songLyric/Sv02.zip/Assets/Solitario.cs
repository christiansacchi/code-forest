using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// https://blogs.unity3d.com/2015/06/19/pixel-perfect-2d/

public class Solitario : MonoBehaviour {

	public GameObject MainDeckZone;
	public Deck MainDeckZone_scrpt;

	public GameObject EXTRActDeckZone;
	public Deck EXTRActDeckZone_scrpt;

	public GameObject handDX;
	public GameObject handSX;

	public int blockingAction = 0;
	private static int BLOCKINGACTION_NONE = 0;
	private static int BLOCKINGACTION_MOVE = 1;
	private static int BLOCKINGACTION_ROT = 2;

	void Start () {
		handDX.GetComponent<Card>().init(true);

		MainDeckZone_scrpt = MainDeckZone.GetComponent<Deck>();
		EXTRActDeckZone_scrpt = EXTRActDeckZone.GetComponent<Deck>();
	}

	void Update () {

		if (blockingAction != BLOCKINGACTION_NONE) {

			if (blockingAction == BLOCKINGACTION_MOVE) {
				if (!handDX.GetComponent<Card>().pushing()) {
					blockingAction = BLOCKINGACTION_NONE;
					handDX =  null;
				}

			} else if (blockingAction == BLOCKINGACTION_ROT) {


			}	


			return;
		}



		if (Input.GetButtonDown("Fire2"))
		{ // Push handDX's card in MainDeckZone

			if (MainDeckZone_scrpt.push(handDX)) {
				blockingAction = BLOCKINGACTION_MOVE;

				Debug.Log("Carta inserita con successo...");
			}
		}



		if (Input.GetButtonDown("Fire1"))
		{ // Pop handDX's card from MainDeckZone to Push in EXTRActDeckZone

			handDX = MainDeckZone_scrpt.pop();
			Debug.Log(handDX);
			if (handDX) {
				Debug.Log("Carta estratta con successo...");
				if (EXTRActDeckZone_scrpt.push(handDX)) {
					blockingAction = BLOCKINGACTION_MOVE;

					Debug.Log("Carta inserita con successo...");
				}
			}
		}



	}
}


