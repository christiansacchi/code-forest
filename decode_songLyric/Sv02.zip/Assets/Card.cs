using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// https://blogs.unity3d.com/2015/06/19/pixel-perfect-2d/

public class Card : MonoBehaviour {

	public int numMaxVal = 13;
	public int seedMaxVal = 4;
	public int id_num_cont = 0;
	public int id_seed_cont = 0;

	private static bool FACE_UP = true;
	private static bool FACE_DOWN = false;
	private static float SPEED_MOVE = 3.0f;
	private static float SPEED_ROTATION = 80.0f;

	public int seedId = -1;
	public int numId = -1;
	public int flip = -1;

	public bool isCardMoving = false;
	public bool isCardPushing = false;
	public bool isCardFlipping = false;

	void Start () {
		if (id_num_cont >= numMaxVal && id_seed_cont >= seedMaxVal) {
			Destroy(gameObject); // DestroyGameObject
			// Destroy(this); // DestroyScriptInstance
		}

		if (++id_num_cont >= numMaxVal) {
			id_seed_cont++;
			id_num_cont = 0;
		}
	}

	public void setSeed (int _seedId) {
		seedId = _seedId;
	}

	public void setNum (int _numId) {
		numId = _numId;
	}

	public void setFlip (bool _flip) {
		if (_flip == FACE_UP)
			flip = 1;
		else if (_flip == FACE_DOWN)
			flip = 0;
	}

	public void switchActive () {
		if (seedId == -1 || numId == -1 || flip == -1) {
			if (id_num_cont == 0) {
				id_num_cont = 12;
				if (id_seed_cont != 0) {
					id_seed_cont--;
				}
			}
			Destroy(gameObject); 
		}

		if (!gameObject.activeInHierarchy)
			gameObject.SetActive(true);
		else gameObject.SetActive(false);

		gameObject.SetActive(true); // CHEAT...
	}

	public void init (bool _flip) {
		setSeed(id_num_cont);
		setNum(id_seed_cont);
		setFlip(_flip);
		switchActive();
	}

	public void init (int _seedId, int _numId, bool _flip)  {
		setSeed(_seedId);
		setNum(_numId);
		setFlip(_flip);
		switchActive();
	}

	public void moving (int newX, int newY) { // isCardMoving

	}

	public bool pushing () { // isCardPushing
		isCardPushing = true;

		Vector3 pA = transform.localPosition;
		Vector3 pB = new Vector3 (0, 0, 0);
		float step = SPEED_MOVE * Time.deltaTime;
		transform.localPosition = Vector3.MoveTowards(pA, pB, step);

		if (pA == pB) {
			isCardPushing = false;
		}

		return isCardPushing;
	}

	public void flipping  () { // isCardFlipping

	}

	public void update () {
		if (isCardPushing)
			pushing();

		if (isCardFlipping)
			flipping();
	}
}

