using System.Collections;
using System.Collections.Generic;
using UnityEngine;

// https://blogs.unity3d.com/2015/06/19/pixel-perfect-2d/

public class Deck : MonoBehaviour {

	public int numCards;
	public int curCards;
	private GameObject stackPoint; // Stack Entry point
	private GameObject lastCardStack; // Nodo all'ultima carta inserita...

	public GameObject cardToPushIn;

	// Deck_Zone
	// - graphic_ontent
	// - stack

	// Card
	// - ...
	// stack

	void Start () {
		lastCardStack = transform.Find("stack").gameObject;
		curCards = 0;
		Debug.Log("start.curCards: "+curCards);
	}
	/*void Update () {
		if (Input.GetButtonDown("Fire1")) {
			if (pop()) {
				Debug.Log("Carta pescata con successo...");
			}
		}
		if (Input.GetButtonDown("Fire2")) {
			if (push(cardToPushIn)) {
				Debug.Log("Carta inserita con successo...");
			}
		}
	}*/

	public bool push (GameObject card) {
		/*if (!card.GetComponent("Card"))
			return false;*/

		if (curCards >= numCards)
			return false;

		card.transform.parent = lastCardStack.transform;
		lastCardStack = card.transform.Find("stack").gameObject;

		curCards++;

		//Debug.Log("push.curCards: "+curCards);
		return true;
	}

	public GameObject pop () {
		if (curCards <= 0) {
			Debug.Log("Trololololol");
			return null;
		}

		GameObject popingCard = lastCardStack.transform.parent.gameObject;
		lastCardStack = popingCard.transform.parent.gameObject;

		/* popingCard.transform.parent = null; */
		
		curCards--;

		Debug.Log("pop.popingCard: "+popingCard);
		return popingCard;
	}

	public GameObject getDeckGivenCard (GameObject card) {
		return card.transform.root.gameObject;
	}
}

/*
Transform curCard;
		while (1) {
			curCard
		}
*/