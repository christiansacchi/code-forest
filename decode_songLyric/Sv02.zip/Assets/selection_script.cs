﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class selection_script : MonoBehaviour {

	public bool isSelectOne = false;
	public Vector3 cuePoint;
	public bool cuePointSlt = false;

	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {

		if (Input.GetButtonDown("Fire2")) {

			RaycastHit hitInfo = new RaycastHit();
			if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hitInfo, Mathf.Infinity)) {

				Debug.Log(  "active: " + hitInfo.collider.GetComponent<move_server>().active + "\n" + 
							"isSelectOne: " + isSelectOne + "\n" + 
							"-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"  );

				if ( !hitInfo.collider.GetComponent<move_server>().active && !isSelectOne ) {
					hitInfo.collider.GetComponent<move_server>().active = true;
					isSelectOne = true;
				} else if ( hitInfo.collider.GetComponent<move_server>().active && isSelectOne ) {
					hitInfo.collider.GetComponent<move_server>().active = false;
					isSelectOne = false;
				}

				Debug.Log(  "active: " + hitInfo.collider.GetComponent<move_server>().active + "\n" + 
							"isSelectOne: " + isSelectOne + "\n" + 
							"-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"  );

			}
		}

		/*// https://www.youtube.com/watch?v=OCGoTiV4kbM

		Vector3 toch = Input.mousePosition;
		float cam_ratio = Camera.main.aspect;
		float cam_size = Camera.main.orthographicSize;
		float cam_size_o = cam_size * cam_ratio;
		float cam_y = (cam_size*-1);
		float cam_y_tot = (cam_size*2);
		float cam_x = (cam_size_o*-1);
		float cam_x_tot = (cam_size_o*2);

		float x = cam_x + cam_x_tot * toch.x / Screen.width;
		float y = cam_y + cam_y_tot * toch.y / Screen.height;

		Vector3 curMousePos = new Vector3(x, y, -10);

		//Debug.Log(curMousePos);

		Debug.DrawRay(curMousePos, transform.TransformDirection(Vector3.forward)*100, Color.green);
		RaycastHit hitInfo = new RaycastHit();
		//if (Physics.Raycast(curMousePos, transform.TransformDirection(Vector3.forward), out hitInfo, 1000))
		if (Physics.Raycast(Camera.main.ScreenPointToRay(Input.mousePosition), out hitInfo, Mathf.Infinity))
			Debug.Log(hitInfo.transform.tag);
		else Debug.Log("Non sto prendendo niente...");*/
	}
}


/*

Touch, struct in UnityEngine

Devices can track a number of different pieces of data 
about a touch
- phase
- position
- single contact or several taps

Properties
- fingerId, The unique index for the touch.
- phase ---> https://docs.unity3d.com/ScriptReference/Touch-phase.html
- position, The position of the touch in pixel coordinates.
- pressure, Describes the phase of the touch.

Altro...
- Input.touchCount, Number of touches. Guaranteed not to change throughout the frame. (Read Only)



-=-=-==-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-
Unity3D mobile develop

- selezionare iOS nella schermata build settings
- poi selezionare l'aspetto ratio piu adatto, se non li vedo molto probabilmente prima devo selezionare iOS
- TOUCH
	- download UnityRemoteApp



// Move a cube

using UnityEngine;
using System.Collections;

public class MoveScript : MonoBehaviour {

	void Start () {}

	void Update () {

		if (Input.touchCount == 1) {
			Touch toch = Input.GetTouch(0);

			// Camera Object FUN FACTs
			float cam_ratio = Camera.aspect;
			float cam_size = Camera.main.orthographicSize;
			float cam_size_o = cam_size * cam_ratio;
			float cam_x = (cam_size*-1);
			float cam_x_tot = (cam_size*2);
			float cam_y = (cam_size_o*-1);
			float cam_y_tot = (cam_size_o*2);

			float x = cam_x + cam_x_tot * touch.position.x / Screen.width;
			float y = cam_y + cam_y_tot * touch.posision.y / Screen.height;

			transform.Translate(x, y, 0);
		}

	}

}

*/