﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class move_server : MonoBehaviour {

	public bool active = false;

	public Vector3 cuePoint;
	public bool cuePointSlt = false;

	// Use this for initialization
	void Start () {
		
	}
	

	public Vector3 screenCordToEnvCord (Vector3 screenCord) {
		Vector3 toch = screenCord;

		// Camera Object FUN FACTs 
		float cam_ratio = Camera.main.aspect;
		float cam_size = Camera.main.orthographicSize;
		float cam_size_o = cam_size * cam_ratio;
		float cam_y = (cam_size*-1);
		float cam_y_tot = (cam_size*2);
		float cam_x = (cam_size_o*-1);
		float cam_x_tot = (cam_size_o*2);

		float x = cam_x + cam_x_tot * toch.x / Screen.width;
		float y = cam_y + cam_y_tot * toch.y / Screen.height;

		return new Vector3(x, y, 0);
	}

	// Update is called once per frame
	void Update () {
		
		if (active)
		{		
				// Rotazione
				var angles = transform.rotation.eulerAngles;
				angles.y += Time.deltaTime * 90;
				transform.rotation = Quaternion.Euler(angles);
				
				float n_angles = transform.rotation.eulerAngles.y;
				if ((n_angles >= 0 && n_angles <= 80) || (n_angles >= 270 && n_angles < 360)) {
					GetComponent<SpriteRenderer>().color = Color.white;
					GetComponent<SpriteRenderer>().sortingOrder = 0;
				} else {
					GetComponent<SpriteRenderer>().color = Color.red;
					GetComponent<SpriteRenderer>().sortingOrder = 3;
				}


				// Traslazione
				if (Input.GetButtonDown("Fire2")) {
					if (!cuePointSlt) {
						cuePoint = screenCordToEnvCord(Input.mousePosition);
						cuePointSlt = true;
					}
					Debug.Log(  "transform.position: " + transform.position + "\n" + 
								"cuePoint: " + cuePoint + "\n" + 
								"-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-=-"  );
				}
				if (cuePointSlt) {
					float speed = 3.0f;
					float step = speed * Time.deltaTime;
					transform.position = Vector3.MoveTowards(transform.position, cuePoint, step);

					if (transform.position == cuePoint) {
						cuePointSlt = false;
					}
				}

				// Spostamento
				if (Input.GetButtonDown("Fire1")) {
					
					Vector3 toch = Input.mousePosition;

					// Camera Object FUN FACTs 
					float cam_ratio = Camera.main.aspect;
					float cam_size = Camera.main.orthographicSize;
					float cam_size_o = cam_size * cam_ratio;
					float cam_y = (cam_size*-1);
					float cam_y_tot = (cam_size*2);
					float cam_x = (cam_size_o*-1);
					float cam_x_tot = (cam_size_o*2);

					float x = cam_x + cam_x_tot * toch.x / Screen.width;
					float y = cam_y + cam_y_tot * toch.y / Screen.height;

					transform.position = new Vector3(x, y, 0);
					// transform.Translate(x, y, 0);
				}
		}

		

	}
}
